<template>
  <v-app>
    <!-- Градиентный фон через слот app -->
    <v-main class="gradient-bg">
      <v-container class="fill-height">
        <v-row justify="center" align="center" class="w-100">
          <v-col cols="12" md="8" lg="6">
            <!-- Заголовок с анимацией -->
            <div class="text-center mb-6">
              <h1 class="text-h3 font-weight-bold white--text text-shadow animate-title">
                ✨ TaskFlow
              </h1>
              <p class="text-subtitle-1 grey--text text--lighten-2 animate-subtitle">
                Организуй свои задачи стильно
              </p>
            </div>

            <!-- Карточка добавления задачи -->
            <v-card class="glass-card pa-4 mb-6 animate-slide-up" elevation="10" rounded="xl">
              <v-text-field
                v-model="newTask"
                label="Новая задача"
                placeholder="Например: Сделать дизайн в Figma"
                variant="solo-filled"
                density="comfortable"
                bg-color="rgba(255,255,255,0.9)"
                class="rounded-lg"
                @keyup.enter="addTask"
              >
                <template v-slot:append-inner>
                  <v-fade-transition>
                    <v-icon
                      v-if="newTask"
                      color="primary"
                      @click="addTask"
                      class="cursor-pointer"
                    >
                      mdi-send-circle
                    </v-icon>
                  </v-fade-transition>
                </template>
              </v-text-field>
            </v-card>

            <!-- Карточка списка задач -->
            <v-card class="glass-card animate-slide-up" elevation="10" rounded="xl" style="transition-delay: 0.1s">
              <v-list bg-color="transparent" class="py-0">
                <v-list-item
                  v-for="(task, index) in tasks"
                  :key="task.id"
                  :class="[
                    'task-item',
                    { 'task-completed': task.completed, 'animate-list-item': index < 3 }
                  ]"
                  :style="{ animationDelay: `${index * 0.03}s` }"
                >
                  <template v-slot:prepend>
                    <v-checkbox-btn
                      v-model="task.completed"
                      :color="task.completed ? 'success' : 'primary'"
                      class="mr-2"
                      hide-details
                    ></v-checkbox-btn>
                  </template>

                  <v-list-item-title>
                    <span
                      class="text-body-1"
                      :class="{ 'task-text-completed': task.completed }"
                      :style="{ fontWeight: task.completed ? 'normal' : '500' }"
                    >
                      {{ task.title }}
                    </span>
                  </v-list-item-title>

                  <template v-slot:append>
                    <v-btn
                      icon
                      variant="text"
                      color="warning-lighten-1"
                      size="small"
                      class="mr-1"
                      @click="openEditDialog(task)"
                    >
                      <v-icon size="small">mdi-pencil</v-icon>
                    </v-btn>
                    <v-btn
                      icon
                      variant="text"
                      color="error-lighten-1"
                      size="small"
                      @click="deleteTask(task.id)"
                    >
                      <v-icon size="small">mdi-delete-outline</v-icon>
                    </v-btn>
                  </template>
                </v-list-item>

                <v-divider v-if="tasks.length === 0" class="my-4"></v-divider>
                
                <!-- Пустое состояние -->
                <div v-if="tasks.length === 0" class="text-center py-8">
                  <v-icon icon="mdi-clipboard-text-outline" size="64" color="grey-lighten-1"></v-icon>
                  <p class="text-grey mt-4">Нет задач. Добавьте первую!</p>
                </div>
              </v-list>

              <v-divider></v-divider>

              <!-- Статистика и действия -->
              <v-card-actions class="pa-4 d-flex justify-space-between flex-wrap">
                <div class="d-flex ga-2">
                  <v-chip color="primary" variant="flat" size="small" class="font-weight-bold">
                    <v-icon start icon="mdi-format-list-checks" size="small"></v-icon>
                    {{ tasks.length }}
                  </v-chip>
                  <v-chip color="success" variant="flat" size="small" class="font-weight-bold">
                    <v-icon start icon="mdi-check-circle" size="small"></v-icon>
                    {{ completedCount }}
                  </v-chip>
                </div>
                <v-btn
                  variant="text"
                  color="error"
                  size="small"
                  prepend-icon="mdi-trash-can-outline"
                  @click="clearCompleted"
                  :disabled="completedCount === 0"
                  class="hover-scale"
                >
                  Очистить выполненные
                </v-btn>
              </v-card-actions>
            </v-card>

            <!-- Кнопка сохранения в localStorage (плавающая) -->
            <v-btn
              class="save-fab"
              color="white"
              icon="mdi-content-save"
              variant="flat"
              size="large"
              elevation="4"
              @click="saveTasks"
            ></v-btn>
          </v-col>
        </v-row>
      </v-container>
    </v-main>

    <!-- Диалог редактирования -->
    <v-dialog v-model="editDialog" max-width="500" persistent>
      <v-card rounded="xl">
        <v-card-title class="text-h6 pa-4 bg-primary text-white">
          ✏️ Редактировать задачу
        </v-card-title>
        <v-card-text class="pt-4">
          <v-text-field
            v-model="editingTask.title"
            label="Название"
            variant="outlined"
            autofocus
            hide-details
          ></v-text-field>
        </v-card-text>
        <v-card-actions class="pa-4">
          <v-spacer></v-spacer>
          <v-btn variant="text" color="grey" @click="editDialog = false">Отмена</v-btn>
          <v-btn color="primary" variant="flat" @click="saveEdit">Сохранить</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Snackbar уведомления -->
    <v-snackbar v-model="snackbar.show" :color="snackbar.color" timeout="2000" location="top" rounded="lg">
      <div class="d-flex align-center ga-2">
        <v-icon :icon="snackbar.icon"></v-icon>
        <span>{{ snackbar.text }}</span>
      </div>
    </v-snackbar>
  </v-app>
</template>

<script>
export default {
  data() {
    return {
      tasks: [],
      newTask: '',
      editDialog: false,
      editingTask: { id: null, title: '', completed: false },
      snackbar: {
        show: false,
        text: '',
        color: 'success',
        icon: 'mdi-check-circle',
      },
    };
  },
  computed: {
    completedCount() {
      return this.tasks.filter(t => t.completed).length;
    },
  },
  mounted() {
    this.loadTasks();
  },
  methods: {
    addTask() {
      if (!this.newTask.trim()) return;
      this.tasks.push({
        id: Date.now(),
        title: this.newTask.trim(),
        completed: false,
      });
      this.newTask = '';
      this.showNotification('Задача добавлена', 'success', 'mdi-plus-circle');
      this.saveTasks();
    },
    deleteTask(id) {
      this.tasks = this.tasks.filter(t => t.id !== id);
      this.showNotification('Задача удалена', 'info', 'mdi-delete-clock');
      this.saveTasks();
    },
    openEditDialog(task) {
      this.editingTask = { ...task };
      this.editDialog = true;
    },
    saveEdit() {
      const index = this.tasks.findIndex(t => t.id === this.editingTask.id);
      if (index !== -1 && this.editingTask.title.trim()) {
        this.tasks[index].title = this.editingTask.title.trim();
        this.showNotification('Задача обновлена', 'warning', 'mdi-pencil-circle');
        this.saveTasks();
      }
      this.editDialog = false;
    },
    clearCompleted() {
      this.tasks = this.tasks.filter(t => !t.completed);
      this.showNotification('Выполненные задачи удалены', 'error', 'mdi-broom');
      this.saveTasks();
    },
    showNotification(text, color, icon) {
      this.snackbar.text = text;
      this.snackbar.color = color;
      this.snackbar.icon = icon || 'mdi-information';
      this.snackbar.show = true;
    },
    saveTasks() {
      localStorage.setItem('vuetify_tasks', JSON.stringify(this.tasks));
      this.showNotification('Сохранено в памяти браузера', 'success', 'mdi-content-save');
    },
    loadTasks() {
      const saved = localStorage.getItem('vuetify_tasks');
      if (saved) {
        this.tasks = JSON.parse(saved);
      } else {
        this.tasks = [
          { id: 1, title: '🌟 Изучить Vuetify 3', completed: false },
          { id: 2, title: '🎨 Применить градиентный фон', completed: false },
          { id: 3, title: '✨ Добавить анимации', completed: false },
          { id: 4, title: '🚀 Загрузить на GitHub', completed: false },
        ];
      }
    },
  },
};
</script>

<style scoped>
/* Градиентный фон во весь экран */
.gradient-bg {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
}

/* Стеклянная карточка (glass morphism) */
.glass-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(2px);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.glass-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 20px 30px -12px rgba(0, 0, 0, 0.2) !important;
}

/* Тени для заголовка */
.text-shadow {
  text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.2);
}

/* Анимация появления */
.animate-title {
  animation: fadeInDown 0.5s ease-out;
}

.animate-subtitle {
  animation: fadeInUp 0.6s ease-out;
}

.animate-slide-up {
  animation: slideUp 0.5s ease-out forwards;
  opacity: 0;
  transform: translateY(20px);
}

.animate-list-item {
  animation: fadeInRight 0.3s ease-out forwards;
  opacity: 0;
}

@keyframes fadeInDown {
  from {
    opacity: 0;
    transform: translateY(-30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes slideUp {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes fadeInRight {
  from {
    opacity: 0;
    transform: translateX(-20px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

/* Стили элементов списка */
.task-item {
  transition: background 0.2s;
  border-radius: 12px;
  margin: 4px 8px;
}

.task-item:hover {
  background: rgba(100, 108, 255, 0.08);
}

.task-completed {
  opacity: 0.8;
  background: linear-gradient(90deg, transparent, rgba(76, 175, 80, 0.05));
}

.task-text-completed {
  text-decoration: line-through;
  color: #9e9e9e;
}

/* Плавающая кнопка сохранения */
.save-fab {
  position: fixed;
  bottom: 24px;
  right: 24px;
  z-index: 100;
  transition: transform 0.2s;
}

.save-fab:hover {
  transform: scale(1.05);
}

/* Анимация для кнопок */
.hover-scale {
  transition: transform 0.1s;
}
.hover-scale:hover {
  transform: scale(1.02);
}

/* Адаптивность */
@media (max-width: 600px) {
  .save-fab {
    bottom: 16px;
    right: 16px;
  }
  .glass-card {
    margin-left: 8px;
    margin-right: 8px;
  }
}
</style>